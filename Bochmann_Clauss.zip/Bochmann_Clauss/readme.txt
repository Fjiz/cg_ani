Hintergrundmusik auf Taste 'P'
Legosteinchen werfen mit 'SPACE'

OrbitControls f�r DirectionalLight